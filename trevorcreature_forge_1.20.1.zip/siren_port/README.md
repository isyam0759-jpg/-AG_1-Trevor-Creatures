# Trevor Creature (Siren Head) - Forge 1.20.1 + GeckoLib 4.8.2

Port dari addon Bedrock "[AG_1] Trevor Creature Add-on". Mod ID: `trevorcreature`.

## Build
1. Download Forge MDK 1.20.1-47.4.0, salin `gradlew`, `gradlew.bat`, dan `gradle/wrapper/gradle-wrapper.jar` ke folder ini.
2. Java 17, lalu `./gradlew build` -> jar di `build/libs/`.
3. Taruh jar + GeckoLib (geckolib-forge-1.20.1-4.8.2) di folder mods.
Dev: `./gradlew runClient`.

## Isi
- `siren_head` (egg di tab Spawn Eggs + tab mod), `siren_sign` (item craft: yellow dye, iron block, paper, 2 iron ingot),
  `siren_sign_staff` (dash, drop dari Siren Head), `siren_weapon` (kepala jatuh, drop xp bottle + netherite block), `siren_sound` (proyektil serangan 8).
- Angka yang bisa di-tweak ada di atas `SirenHeadEntity` (IMPULSE, KNOCK_SCALE, PLAYER_MELEE_BONUS, dll).
