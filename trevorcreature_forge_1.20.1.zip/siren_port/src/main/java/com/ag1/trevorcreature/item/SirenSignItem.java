package com.ag1.trevorcreature.item;

import com.ag1.trevorcreature.entity.SirenSignEntity;
import com.ag1.trevorcreature.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Bedrock "ag1:item_shign" (entity_placer -> ag1:siren_sign). */
public class SirenSignItem extends Item {
    public SirenSignItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!(level instanceof ServerLevel sl)) return InteractionResult.SUCCESS;
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        SirenSignEntity sign = ModEntities.SIREN_SIGN.get().create(sl);
        if (sign == null) return InteractionResult.FAIL;
        sign.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, ctx.getRotation(), 0.0F);
        sl.addFreshEntity(sign);
        if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
