package com.ag1.trevorcreature.registry;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import com.ag1.trevorcreature.entity.SirenHeadEntity;
import com.ag1.trevorcreature.entity.SirenSignEntity;
import com.ag1.trevorcreature.entity.SirenSoundEntity;
import com.ag1.trevorcreature.entity.SirenWeaponEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);

    public static final RegistryObject<EntityType<SirenHeadEntity>> SIREN_HEAD = ENTITIES.register("siren_head",
            () -> EntityType.Builder.<SirenHeadEntity>of(SirenHeadEntity::new, MobCategory.MONSTER)
                    .sized(1.5F, 12.0F).fireImmune().clientTrackingRange(24).updateInterval(2)
                    .build(MOD_ID + ":siren_head"));

    public static final RegistryObject<EntityType<SirenSignEntity>> SIREN_SIGN = ENTITIES.register("siren_sign",
            () -> EntityType.Builder.<SirenSignEntity>of(SirenSignEntity::new, MobCategory.MISC)
                    .sized(1.0F, 3.0F).clientTrackingRange(10).updateInterval(20)
                    .build(MOD_ID + ":siren_sign"));

    public static final RegistryObject<EntityType<SirenWeaponEntity>> SIREN_WEAPON = ENTITIES.register("siren_weapon",
            () -> EntityType.Builder.<SirenWeaponEntity>of(SirenWeaponEntity::new, MobCategory.MISC)
                    .sized(1.5F, 1.5F).fireImmune().clientTrackingRange(16).updateInterval(3)
                    .build(MOD_ID + ":siren_weapon"));

    public static final RegistryObject<EntityType<SirenSoundEntity>> SIREN_SOUND = ENTITIES.register("siren_sound",
            () -> EntityType.Builder.<SirenSoundEntity>of(SirenSoundEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(8).updateInterval(2)
                    .build(MOD_ID + ":siren_sound"));

    private ModEntities() {}
}
