package com.ag1.trevorcreature.client;

import com.ag1.trevorcreature.entity.SirenHeadEntity;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

/** Idle siren ambience that follows the entity and stops as soon as it attacks / dies (Bedrock: /music stop). */
public class SirenIdleSoundInstance extends AbstractTickableSoundInstance {
    private final SirenHeadEntity entity;

    public SirenIdleSoundInstance(SirenHeadEntity entity, SoundEvent sound) {
        super(sound, SoundSource.HOSTILE, SoundInstance.createUnseededRandom());
        this.entity = entity;
        this.looping = false;
        this.delay = 0;
        this.volume = 0.8F;
        this.pitch = 1.0F;
        this.attenuation = SoundInstance.Attenuation.LINEAR;
        this.x = entity.getX();
        this.y = entity.getY() + 8.0D;
        this.z = entity.getZ();
    }

    @Override
    public void tick() {
        if (entity.isRemoved() || entity.isDeadOrDying() || entity.getState() != SirenHeadEntity.IDLE) {
            this.stop();
            return;
        }
        this.x = entity.getX();
        this.y = entity.getY() + 8.0D;
        this.z = entity.getZ();
    }
}
