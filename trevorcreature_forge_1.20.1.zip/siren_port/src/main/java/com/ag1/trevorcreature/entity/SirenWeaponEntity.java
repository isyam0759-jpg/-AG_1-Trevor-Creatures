package com.ag1.trevorcreature.entity;

import com.ag1.trevorcreature.registry.ModSounds;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Port of Bedrock "ag1:siren_weapon": the severed head that drops when Siren Head dies - kill it for the loot. */
public class SirenWeaponEntity extends Mob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public SirenWeaponEntity(EntityType<? extends SirenWeaponEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide && this.tickCount % 3 == 0) {
            this.level().addParticle(new DustParticleOptions(new Vector3f(0.55F, 0.0F, 0.0F), 1.2F),
                    getX() + (random.nextDouble() - 0.5D) * 1.0D, getY() + 1.0D + random.nextDouble(),
                    getZ() + (random.nextDouble() - 0.5D) * 1.0D, 0.0D, -0.05D, 0.0D);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // Bedrock: 1 HP, any damage kills it
        return super.hurt(source, Math.max(amount, 2.0F));
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.0D, getZ(), 4, 0.8D, 0.5D, 0.8D, 0.0D);
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.SIREN_EXPLODE.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    /** no slow "fall over" animation, remove right after the loot dropped */
    @Override
    protected void tickDeath() {
        if (!this.level().isClientSide) {
            this.level().broadcastEntityEvent(this, (byte) 60);
            this.remove(Entity.RemovalReason.KILLED);
        }
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean canBeLeashed(Player p) { return false; }
    @Override public boolean causeFallDamage(float d, float m, DamageSource s) { return false; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Bedrock: "move" is always on, "up" while airborne, "down" once landed
        controllers.add(new AnimationController<SirenWeaponEntity>(this, "move", 0, state -> {
            state.getController().setAnimation(RawAnimation.begin().then("animation.Sw_ag1.move", Animation.LoopType.DEFAULT));
            return PlayState.CONTINUE;
        }));
        controllers.add(new AnimationController<SirenWeaponEntity>(this, "fall", 4, state -> {
            boolean grounded = this.onGround() || this.isInWater();
            state.getController().setAnimation(RawAnimation.begin()
                    .then(grounded ? "animation.Sw_ag1.down" : "animation.Sw_ag1.up", Animation.LoopType.DEFAULT));
            return PlayState.CONTINUE;
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.cache; }
}
