package com.ag1.trevorcreature.registry;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MOD_ID, name)));
    }

    /** idle ambience clips (one event per clip so the client knows how long each one lasts) */
    public static final RegistryObject<SoundEvent> SIREN_IDLE_1 = reg("siren_idle_1"); // 40.5 s
    public static final RegistryObject<SoundEvent> SIREN_IDLE_2 = reg("siren_idle_2"); // 49.9 s
    public static final RegistryObject<SoundEvent> SIREN_IDLE_3 = reg("siren_idle_3"); // 45.3 s
    public static final RegistryObject<SoundEvent> SIREN_IDLE_4 = reg("siren_idle_4"); // 21.0 s
    public static final RegistryObject<SoundEvent> SIREN_IDLE_5 = reg("siren_idle_5"); // 37.9 s
    /** length of the idle clips in ticks, same order as above */
    public static final int[] IDLE_TICKS = {811, 999, 907, 420, 759};

    public static final RegistryObject<SoundEvent> SIREN_STEP = reg("siren_step");
    public static final RegistryObject<SoundEvent> SIREN_GROUND = reg("siren_ground");
    public static final RegistryObject<SoundEvent> SIREN_IMPACT = reg("siren_impact");
    public static final RegistryObject<SoundEvent> SIREN_SWOOSH = reg("siren_swoosh");
    public static final RegistryObject<SoundEvent> SIREN_BIGWOOSH = reg("siren_bigwoosh");
    public static final RegistryObject<SoundEvent> SIREN_EXPLODE = reg("siren_explode");
    public static final RegistryObject<SoundEvent> SIREN_SHORTSIREN = reg("siren_shortsiren");
    public static final RegistryObject<SoundEvent> SIREN_ATTSIREN = reg("siren_attsiren");

    public static List<RegistryObject<SoundEvent>> idleClips() {
        return List.of(SIREN_IDLE_1, SIREN_IDLE_2, SIREN_IDLE_3, SIREN_IDLE_4, SIREN_IDLE_5);
    }

    /** maps the "sound_effects" names inside the GeckoLib animation file to sound events */
    public static SoundEvent byKeyframe(String name) {
        if (name == null) return null;
        return switch (name) {
            case "swoosh" -> SIREN_SWOOSH.get();
            case "bigwoosh" -> SIREN_BIGWOOSH.get();
            case "impact" -> SIREN_IMPACT.get();
            case "ground" -> SIREN_GROUND.get();
            case "explode" -> SIREN_EXPLODE.get();
            case "shortsiren" -> SIREN_SHORTSIREN.get();
            case "attsiren" -> SIREN_ATTSIREN.get();
            default -> null;
        };
    }

    private ModSounds() {}
}
