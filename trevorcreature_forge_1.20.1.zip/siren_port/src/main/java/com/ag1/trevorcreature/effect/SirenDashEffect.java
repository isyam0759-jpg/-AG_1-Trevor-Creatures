package com.ag1.trevorcreature.effect;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** Replaces the Bedrock "shignatt" helper entity: speed burst + dust trail while dashing with the Siren Sign Staff. */
public class SirenDashEffect extends MobEffect {
    public SirenDashEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xE0C040);
        // Bedrock: speed amplifier 5 (= +180 %)
        this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "5b0d2b4a-9d1e-4a33-8c0f-1a2b3c4d5e6f",
                1.8D, AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return true;
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CLOUD, entity.getX(), entity.getY() + 0.1D, entity.getZ(), 5, 0.3D, 0.1D, 0.3D, 0.02D);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, entity.getX(), entity.getY() + 1.0D, entity.getZ(), 3, 0.3D, 0.5D, 0.3D, 0.05D);
        }
    }
}
