package com.ag1.trevorcreature.client;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Replacement for Bedrock /camerashake. */
@Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CameraShake {
    private static float intensity;
    private static float remaining;
    private static float duration = 1.0F;

    public static void add(float amount, float seconds) {
        float current = remaining > 0 ? intensity * (remaining / duration) : 0.0F;
        if (amount >= current) {
            intensity = amount;
            duration = Math.max(seconds, 0.05F);
            remaining = duration;
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        if (remaining <= 0.0F) return;
        float amp = intensity * Mth.clamp(remaining / duration, 0.0F, 1.0F) * 1.2F;
        java.util.Random r = new java.util.Random();
        e.setPitch(e.getPitch() + (r.nextFloat() - 0.5F) * amp);
        e.setYaw(e.getYaw() + (r.nextFloat() - 0.5F) * amp);
        e.setRoll(e.getRoll() + (r.nextFloat() - 0.5F) * amp);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && remaining > 0.0F) remaining -= 0.05F;
    }

    private CameraShake() {}
}
