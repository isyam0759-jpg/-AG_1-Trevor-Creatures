package com.ag1.trevorcreature.item;

import com.ag1.trevorcreature.entity.SirenHeadEntity;
import com.ag1.trevorcreature.registry.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Bedrock "ag1:shign": dash with a shockwave behind you. 2 s resistance, 1 s speed burst + trail,
 * knockback (0 damage) on everything within 11 blocks, 5 s cooldown.
 */
public class SirenSignStaffItem extends Item {
    public SirenSignStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);

        if (level instanceof ServerLevel sl) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, false, false));
            player.addEffect(new MobEffectInstance(ModEffects.SIREN_DASH.get(), 20, 0, false, false));

            Vec3 look = player.getLookAngle();
            Vec3 flat = new Vec3(look.x, 0.0D, look.z).normalize();
            Vec3 center = player.position().subtract(flat.scale(1.0D));
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(11.0D),
                    e -> e != player && e.isAlive() && !SirenHeadEntity.isSirenFamily(e)
                            && e.distanceToSqr(center.x, center.y, center.z) <= 121.0D)) {
                double dx = e.getX() - center.x, dz = e.getZ() - center.z;
                double len = Math.max(Math.sqrt(dx * dx + dz * dz), 0.001D);
                e.setDeltaMovement(e.getDeltaMovement().add(dx / len * 1.4D, 0.45D, dz / len * 1.4D));
                e.hurtMarked = true;
            }
            // little forward kick on top of the speed effect
            player.setDeltaMovement(player.getDeltaMovement().add(flat.x * 0.8D, 0.1D, flat.z * 0.8D));
            player.hurtMarked = true;

            sl.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.2D, center.z, 40, 1.5D, 0.1D, 1.5D, 0.15D);
            sl.sendParticles(ParticleTypes.POOF, center.x, center.y + 0.5D, center.z, 25, 1.0D, 0.3D, 1.0D, 0.1D);
        }
        player.getCooldowns().addCooldown(this, 100);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
