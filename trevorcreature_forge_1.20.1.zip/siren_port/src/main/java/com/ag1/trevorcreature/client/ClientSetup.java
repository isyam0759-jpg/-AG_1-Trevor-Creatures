package com.ag1.trevorcreature.client;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import com.ag1.trevorcreature.entity.SirenHeadEntity;
import com.ag1.trevorcreature.entity.SirenSignEntity;
import com.ag1.trevorcreature.entity.SirenWeaponEntity;
import com.ag1.trevorcreature.registry.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

@Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SIREN_HEAD.get(), ctx -> {
            GeoEntityRenderer<SirenHeadEntity> r = new GeoEntityRenderer<>(ctx,
                    new DefaultedEntityGeoModel<SirenHeadEntity>(new ResourceLocation(MOD_ID, "siren_head")));
            r.withScale(2.5F); // Bedrock minecraft:scale 2.5
            return r;
        });
        event.registerEntityRenderer(ModEntities.SIREN_SIGN.get(), ctx ->
                new GeoEntityRenderer<SirenSignEntity>(ctx,
                        new DefaultedEntityGeoModel<SirenSignEntity>(new ResourceLocation(MOD_ID, "siren_sign"))));
        event.registerEntityRenderer(ModEntities.SIREN_WEAPON.get(), ctx -> {
            GeoEntityRenderer<SirenWeaponEntity> r = new GeoEntityRenderer<>(ctx,
                    new DefaultedEntityGeoModel<SirenWeaponEntity>(new ResourceLocation(MOD_ID, "siren_weapon")));
            r.withScale(2.5F);
            return r;
        });
        event.registerEntityRenderer(ModEntities.SIREN_SOUND.get(), NoopRenderer::new);
    }
}
