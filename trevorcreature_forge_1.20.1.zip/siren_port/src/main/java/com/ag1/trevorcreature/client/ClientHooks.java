package com.ag1.trevorcreature.client;

import com.ag1.trevorcreature.entity.SirenHeadEntity;
import com.ag1.trevorcreature.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Everything that touches client-only classes lives here (never loaded on a dedicated server). */
public final class ClientHooks {

    /** idle ambience: play one random clip, wait, play another - only while the Siren is idle */
    public static void tickHead(SirenHeadEntity e) {
        if (e.isDeadOrDying() || e.getState() != SirenHeadEntity.IDLE) {
            e.clientAmbient = null;
            return;
        }
        if (e.clientAmbient != null && e.tickCount < e.clientAmbientUntil) return;
        if (e.clientAmbient != null) e.clientAmbient = null;
        if (e.tickCount < e.clientAmbientUntil) return;
        Player p = Minecraft.getInstance().player;
        if (p == null || p.distanceTo(e) > 100.0F) return;

        int i = e.getRandom().nextInt(5);
        SoundEvent ev = ModSounds.idleClips().get(i).get();
        SirenIdleSoundInstance inst = new SirenIdleSoundInstance(e, ev);
        Minecraft.getInstance().getSoundManager().play(inst);
        e.clientAmbient = inst;
        e.clientAmbientUntil = e.tickCount + ModSounds.IDLE_TICKS[i] + 100 + e.getRandom().nextInt(300);
    }

    public static void shakeCamera(SirenHeadEntity e, byte id) {
        Player p = Minecraft.getInstance().player;
        if (p == null) return;
        float dist = p.distanceTo(e);
        if (dist > 100.0F) return;
        float falloff = 1.0F - 0.6F * (dist / 100.0F);
        switch (id) {
            case 100: CameraShake.add(1.0F * falloff, 0.5F); break;
            case 101: CameraShake.add(1.5F * falloff, 1.25F); break;
            case 102: CameraShake.add(2.0F * falloff, 1.0F); break;
            case 103: CameraShake.add(0.4F * falloff, 0.2F); break;
            default: break;
        }
    }

    /** Bedrock particle effects mapped onto vanilla particles. Locator "shockwave_<px>" = distance in model pixels. */
    public static void onParticle(SirenHeadEntity e, String effect, String locator) {
        Level lvl = e.level();
        float yaw = e.yBodyRot * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(yaw), fz = Mth.cos(yaw);
        BlockState ground = lvl.getBlockState(e.blockPosition().below());
        if (ground.isAir()) ground = Blocks.DIRT.defaultBlockState();
        ParticleOptions dirt = new BlockParticleOption(ParticleTypes.BLOCK, ground);

        if ("footdust".equals(effect)) {
            double side = "foot".equals(locator) ? 1.0D : -1.0D;
            double px = e.getX() + (-Mth.cos(yaw)) * side * 0.5D;
            double pz = e.getZ() + (-Mth.sin(yaw)) * side * 0.5D;
            lvl.playLocalSound(px, e.getY(), pz, ModSounds.SIREN_STEP.get(), SoundSource.HOSTILE, 1.0F, 1.0F, false);
            Player p = Minecraft.getInstance().player;
            if (p != null && p.distanceTo(e) < 100.0F) CameraShake.add(0.3F * (1.0F - p.distanceTo(e) / 100.0F), 0.3F);
            for (int i = 0; i < 8; i++) {
                double a = i / 8.0D * Math.PI * 2.0D;
                lvl.addParticle(ParticleTypes.POOF, px, e.getY() + 0.1D, pz, Math.cos(a) * 0.15D, 0.02D, Math.sin(a) * 0.15D);
            }
            return;
        }

        double dist = 0.0D;
        if (locator != null && locator.startsWith("shockwave_")) {
            try { dist = Integer.parseInt(locator.substring(10)) / 16.0D * 2.5D; } catch (NumberFormatException ignored) { }
        }
        double cx = e.getX() + fx * dist, cz = e.getZ() + fz * dist, cy = e.getY() + 0.1D;
        switch (effect) {
            case "shockwave":
            case "shockwave2": {
                double speed = "shockwave".equals(effect) ? 0.6D : 1.0D;
                for (int i = 0; i < 24; i++) {
                    double a = i / 24.0D * Math.PI * 2.0D;
                    lvl.addParticle(ParticleTypes.CLOUD, cx + Math.cos(a) * 0.6D, cy, cz + Math.sin(a) * 0.6D,
                            Math.cos(a) * speed, 0.03D, Math.sin(a) * speed);
                }
                break;
            }
            case "dust_impact":
            case "impact":
                lvl.addParticle(ParticleTypes.EXPLOSION, cx, cy + 0.5D, cz, 1.0D, 0.0D, 0.0D);
                break;
            case "dirt":
                for (int i = 0; i < 24; i++) {
                    lvl.addParticle(dirt, cx + (e.getRandom().nextDouble() - 0.5D) * 3.0D, cy,
                            cz + (e.getRandom().nextDouble() - 0.5D) * 3.0D, 0.0D, 0.4D + e.getRandom().nextDouble() * 0.4D, 0.0D);
                }
                break;
            case "dust":
            case "dust2":
            case "dustcloud":
            case "dustcloud2":
            case "cloudimpact":
                for (int i = 0; i < 10; i++) {
                    lvl.addParticle(ParticleTypes.LARGE_SMOKE, cx + (e.getRandom().nextDouble() - 0.5D) * 3.0D, cy,
                            cz + (e.getRandom().nextDouble() - 0.5D) * 3.0D, 0.0D, 0.08D, 0.0D);
                }
                break;
            default:
                break;
        }
    }

    private ClientHooks() {}
}
