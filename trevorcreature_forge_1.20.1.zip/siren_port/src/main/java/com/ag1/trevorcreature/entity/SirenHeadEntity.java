package com.ag1.trevorcreature.entity;

import com.ag1.trevorcreature.client.ClientHooks;
import com.ag1.trevorcreature.registry.ModEntities;
import com.ag1.trevorcreature.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.keyframe.event.ParticleKeyframeEvent;
import software.bernie.geckolib.core.keyframe.event.SoundKeyframeEvent;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Port of Bedrock "ag1:siren_head".
 *
 * State machine (replaces the Bedrock properties ag1:att / ag1:jum / ag1:ded + component groups + timeline commands):
 *   0 idle, 1-8 attacks, 50 rush (wind-up), 51 rush, 60 jump. Death = vanilla death with a 7 s animation.
 */
public class SirenHeadEntity extends Monster implements GeoEntity {

    // ---------------------------------------------------------------- states
    public static final int IDLE = 0;
    public static final int RUSH_READY = 50;
    public static final int RUSH = 51;
    public static final int JUMP = 60;

    // durations in ticks (Bedrock timers: 3.52 / 3.22 / 4.22 / 3.22 / 3.22 / 4.75 / 4.75 / 5.75 s, rush 1.5 + 2 s, jump 2.42 s)
    private static final int[] ATTACK_TICKS = {0, 70, 64, 84, 64, 64, 95, 95, 115};
    private static final int[] ATTACK_WEIGHTS = {0, 10, 10, 9, 10, 10, 10, 10, 8};
    private static final int RUSH_WEIGHT = 8;
    private static final int JUMP_WEIGHT = 7;
    private static final int RUSH_READY_TICKS = 30;
    private static final int RUSH_TICKS = 40;
    private static final int JUMP_TICKS = 49;
    private static final int DEATH_TICKS = 140; // 7 s
    private static final int ATTACK_RANGE = 15; // "target_nearby_sensor inside_range"

    // Bedrock applyImpulse -> Java velocity. Tweak these if the lunges feel too short / too long.
    private static final double IMPULSE = 0.6D;
    private static final double IMPULSE_Y = 0.9D;
    private static final double KNOCK_SCALE = 0.45D;
    private static final double KNOCK_SCALE_Y = 0.6D;

    /** Bedrock "hurt_on_condition" (300 extra damage per player melee hit) */
    private static final float PLAYER_MELEE_BONUS = 300.0F;

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_SUMMONED =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.BOOLEAN);

    private static final String ANIM_IDLE = "animation.Sh_ag1.gen";
    private static final String ANIM_WALK = "animation.Sh_ag1.mov";
    private static final String ANIM_RUN = "animation.Sh_ag1.run";
    private static final String ANIM_DED = "animation.Sh_ag1.ded";
    private static final String ANIM_DED_SIREN = "animation.Sh_ag1.dedsiren";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("\u00a7l\u00a7f\u00a7k1\u00a7r\u00a7l\u00a77Siren Head\u00a7r\u00a7l\u00a7f\u00a7k1"),
            BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);

    private int stateTicks;
    private int idleCooldown = 40;
    private final List<UUID> grabbed = new ArrayList<>();
    private DamageSource deathSource;
    /** damage multiplier so that 7500 "Bedrock HP" fits into Java's 1024 max-health cap */
    private double hpScale = 1000.0D / 7500.0D;
    private int lastStepTick = -100;
    private float smoothSpeed; // blocks/tick, smoothed - drives idle / walk / run animation

    // client-only bookkeeping (kept as plain fields so this class never loads client classes on a server)
    public Object clientAmbient;
    public int clientAmbientUntil;

    public SirenHeadEntity(EntityType<? extends SirenHeadEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setMaxUpStep(6.0F);
        this.setPersistenceRequired();
        this.bossEvent.setDarkenScreen(true);
        this.setHealth(this.getMaxHealth());
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1000.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.FOLLOW_RANGE, 200.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D);
    }

    // ---------------------------------------------------------------- data
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STATE, IDLE);
        this.entityData.define(DATA_SUMMONED, false);
    }

    public int getState() { return this.entityData.get(DATA_STATE); }
    private void setState(int s) { this.entityData.set(DATA_STATE, s); }
    public boolean isSummoned() { return this.entityData.get(DATA_SUMMONED); }

    /** Called by the Siren Sign: Bedrock group "true" (700 HP, boss bar, 64 block range). */
    public void setSummoned(boolean summoned) {
        this.entityData.set(DATA_SUMMONED, summoned);
        if (summoned) {
            this.hpScale = 1.0D;
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(700.0D);
            this.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(64.0D);
            this.setHealth(700.0F);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Summoned", isSummoned());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        boolean s = tag.getBoolean("Summoned");
        this.entityData.set(DATA_SUMMONED, s);
        this.hpScale = s ? 1.0D : 1000.0D / 7500.0D;
        if (this.hasCustomName()) this.bossEvent.setName(this.getDisplayName());
    }

    // ---------------------------------------------------------------- AI
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BreakDoorGoal(this, difficulty -> true));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, true) {
            @Override public boolean canUse() { return isIdleState() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isIdleState() && super.canContinueToUse(); }
        });
        // idle: only walk around, never random head/body looking (the Bedrock entity has no look_around either)
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.7D) {
            @Override public boolean canUse() { return isIdleState() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isIdleState() && super.canContinueToUse(); }
        });
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, false, false, this::isPrey));
    }

    private boolean isIdleState() { return getState() == IDLE; }

    private boolean isPrey(LivingEntity e) {
        return e instanceof AbstractVillager || e instanceof AbstractIllager || e instanceof Ravager
                || e instanceof IronGolem || (!isSummoned() && e instanceof Pig);
    }

    // ---------------------------------------------------------------- tick
    @Override
    public void tick() {
        super.tick();
        double mdx = this.getX() - this.xo, mdz = this.getZ() - this.zo;
        this.smoothSpeed += ((float) Math.sqrt(mdx * mdx + mdz * mdz) - this.smoothSpeed) * 0.4F;
        if (this.level().isClientSide) {
            ClientHooks.tickHead(this);
            return;
        }
        if (!this.isAlive()) return;
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        serverLogic();
    }

    private void serverLogic() {
        // Bedrock "break_blocks": leaves
        if (this.tickCount % 4 == 0 && ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            AABB box = this.getBoundingBox().inflate(0.6D, 0.0D, 0.6D);
            for (BlockPos p : BlockPos.betweenClosed(BlockPos.containing(box.minX, box.minY, box.minZ), BlockPos.containing(box.maxX, box.maxY, box.maxZ))) {
                if (this.level().getBlockState(p).is(BlockTags.LEAVES)) this.level().destroyBlock(p, true, this);
            }
        }

        int state = getState();
        LivingEntity target = getTarget();
        if (state == IDLE) {
            if (idleCooldown > 0) { idleCooldown--; return; }
            if (target != null && target.isAlive()) {
                double dx = target.getX() - getX(), dz = target.getZ() - getZ();
                if (dx * dx + dz * dz <= ATTACK_RANGE * ATTACK_RANGE) chooseAttack(target);
            }
            return;
        }

        stateTicks++;
        timeline(state, stateTicks, target);
        if (stateTicks >= durationOf(state)) endState(state);
    }

    private int durationOf(int s) {
        if (s >= 1 && s <= 8) return ATTACK_TICKS[s];
        switch (s) {
            case RUSH_READY: return RUSH_READY_TICKS;
            case RUSH: return RUSH_TICKS;
            case JUMP: return JUMP_TICKS;
            default: return 0;
        }
    }

    private void chooseAttack(LivingEntity target) {
        int total = RUSH_WEIGHT + JUMP_WEIGHT;
        for (int i = 1; i <= 8; i++) total += ATTACK_WEIGHTS[i];
        int roll = this.random.nextInt(total);
        int next = -1;
        for (int i = 1; i <= 8 && next < 0; i++) {
            roll -= ATTACK_WEIGHTS[i];
            if (roll < 0) next = i;
        }
        if (next < 0) {
            roll -= RUSH_WEIGHT;
            next = roll < 0 ? RUSH_READY : JUMP;
        }
        faceTarget(target);
        getNavigation().stop();
        stateTicks = -1;
        setState(next);
    }

    private void endState(int state) {
        stateTicks = 0;
        grabbed.clear();
        if (state == RUSH_READY) {           // wind-up finished -> actual rush
            setState(RUSH);
            stateTicks = -1;
            return;
        }
        setState(IDLE);
        idleCooldown = 8;
    }

    /** Port of the Bedrock animation timelines (shag_attack ... shag_jump). t is in ticks since the state began. */
    private void timeline(int state, int t, LivingEntity target) {
        ServerLevel sl = (ServerLevel) this.level();
        switch (state) {
            case 1:
                if (t == 0) lunge(0, 2.5);
                if (t == 30) slam(9.0D, false);
                break;
            case 2:
                if (t == 20) lunge(0, 1.5);
                if (t == 26) slam(6.0D, false);
                break;
            case 3:
                if (t == 16) lunge(0.5, 5.5);
                if (t == 18) {
                    shake(100);
                    for (LivingEntity v : victims(position(), 10.0D)) grabbed.add(v.getUUID());
                    for (LivingEntity v : victims(position(), 15.0D)) hit(v, 19.0F);
                }
                if (t >= 18 && t < 35) pullGrabbed();
                if (t == 35) { grabbed.clear(); slam(8.0D, false); }
                break;
            case 4:
                if (t == 20) lunge(0, 2.5);
                if (t == 25) slam(6.0D, false);
                break;
            case 5:
                if (t == 10) lunge(0, 3.0);
                if (t == 30) slam(5.0D, false);
                break;
            case 6:
                if (t == 13) lunge(0, 2.5);
                if (t == 20) { shake(100); smash(forwardPoint(7.0D), 12.5D, 19.0F); slow(forwardPoint(7.0D), 13.5D, 60); }
                if (t == 60) slam(7.0D, false);
                break;
            case 7:
                if (t == 13) lunge(0, 2.5);
                if (t == 20) { shake(100); smash(forwardPoint(6.0D), 12.5D, 19.0F); slow(forwardPoint(6.0D), 13.5D, 60); }
                if (t == 53) slam(6.0D, true);
                break;
            case 8:   // sound-wave attack: continuous damage + rain of sound projectiles
                if (t % 10 == 0) {
                    for (LivingEntity v : victims(position(), 17.5D)) {
                        hit(v, 3.0F);
                        v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2, false, true));
                    }
                    shake(103);
                }
                if (t % 4 == 0 && t < 100) fireSoundProjectile();
                break;
            case RUSH_READY:
                if (target != null && t % 5 == 0) faceTarget(target);
                break;
            case RUSH:
                if (t % 4 == 0) {
                    if (target != null) faceTarget(target);
                    lunge(0, 1.5);
                    for (LivingEntity v : victims(position(), 7.0D)) hit(v, 19.0F);
                }
                break;
            case JUMP:
                if (t == 16) lunge(0.5, -5.5);
                if (t == 33) { shake(100); for (LivingEntity v : victims(position(), 15.0D)) hit(v, 19.0F); }
                break;
            default:
                break;
        }
    }

    // ---------------------------------------------------------------- attack helpers
    private Vec3 forwardPoint(double dist) {
        Vec3 f = Vec3.directionFromRotation(0.0F, this.yBodyRot);
        return position().add(f.x * dist, 0.0D, f.z * dist);
    }

    /** Bedrock "/scriptevent ag1:movement 0 y move" -> impulse along the facing direction. */
    private void lunge(double y, double move) {
        Vec3 f = Vec3.directionFromRotation(0.0F, this.yBodyRot);
        this.setDeltaMovement(this.getDeltaMovement().add(f.x * move * IMPULSE, y * IMPULSE_Y, f.z * move * IMPULSE));
        this.hasImpulse = true;
    }

    private void faceTarget(LivingEntity t) {
        float yaw = (float) (Mth.atan2(t.getZ() - getZ(), t.getX() - getX()) * (180.0D / Math.PI)) - 90.0F;
        this.setYRot(yaw);
        this.yRotO = yaw;
        this.yBodyRot = yaw;
        this.yBodyRotO = yaw;
        this.setYHeadRot(yaw);
    }

    public static boolean isSirenFamily(Entity e) {
        return e instanceof SirenHeadEntity || e instanceof SirenWeaponEntity || e instanceof SirenSignEntity
                || e instanceof SirenSoundEntity;
    }

    private List<LivingEntity> victims(Vec3 c, double r) {
        AABB box = new AABB(c, c).inflate(r);
        return this.level().getEntitiesOfClass(LivingEntity.class, box, e ->
                e != this && e.isAlive() && !isSirenFamily(e)
                        && !(e instanceof Player p && (p.isCreative() || p.isSpectator()))
                        && e.distanceToSqr(c.x, c.y, c.z) <= r * r);
    }

    private void hit(LivingEntity v, float dmg) {
        v.hurt(this.damageSources().mobAttack(this), dmg);
    }

    private void smash(Vec3 center, double r, float dmg) {
        for (LivingEntity v : victims(center, r)) hit(v, dmg);
    }

    private void slow(Vec3 center, double r, int ticks) {
        for (LivingEntity v : victims(center, r)) v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 2, false, true));
    }

    /** Bedrock "entity:shknock" / "entity:shknockup": area knockback (+22 damage for non-players). */
    private void slam(double dist, boolean up) {
        Vec3 c = forwardPoint(dist);
        shake(100);
        for (LivingEntity v : victims(c, 12.5D)) {
            double dx = v.getX() - c.x, dz = v.getZ() - c.z;
            double len = Math.max(Math.sqrt(dx * dx + dz * dz), 0.001D);
            dx /= len;
            dz /= len;
            if (v instanceof Player) {
                double h = up ? 0.9D : 1.1D;
                v.setDeltaMovement(v.getDeltaMovement().add(dx * h, up ? 0.9D : 0.45D, dz * h));
            } else {
                double h = (up ? 2.5D : 2.75D) * KNOCK_SCALE;
                double y = (up ? 1.85D : 0.5D) * KNOCK_SCALE_Y;
                hit(v, 22.0F);
                v.setDeltaMovement(v.getDeltaMovement().add(dx * h, y, dz * h));
            }
            v.hurtMarked = true;
        }
        ((ServerLevel) this.level()).sendParticles(ParticleTypes.EXPLOSION, c.x, c.y + 0.5D, c.z, 3, 2.0D, 0.2D, 2.0D, 0.0D);
    }

    /** Attack 3: Bedrock tp @e[tag=siren_grabbed] ^^^9 facing @s, and clears the blocks above them. */
    private void pullGrabbed() {
        ServerLevel sl = (ServerLevel) this.level();
        Vec3 dest = forwardPoint(9.0D);
        boolean grief = ForgeEventFactory.getMobGriefingEvent(sl, this);
        for (UUID id : grabbed) {
            Entity e = sl.getEntity(id);
            if (!(e instanceof LivingEntity le) || !le.isAlive()) continue;
            double yy = this.getY();
            if (grief) {
                BlockPos base = BlockPos.containing(dest.x, yy, dest.z);
                for (int dy = 0; dy <= 3; dy++) {
                    BlockPos bp = base.above(dy);
                    BlockState bs = sl.getBlockState(bp);
                    if (!bs.isAir() && bs.getDestroySpeed(sl, bp) >= 0.0F) sl.destroyBlock(bp, true, this);
                }
            }
            float yaw = (float) (Mth.atan2(getZ() - dest.z, getX() - dest.x) * (180.0D / Math.PI)) - 90.0F;
            if (le instanceof ServerPlayer sp) sp.connection.teleport(dest.x, yy, dest.z, yaw, 0.0F);
            else le.moveTo(dest.x, yy, dest.z, yaw, 0.0F);
            le.setDeltaMovement(Vec3.ZERO);
            le.fallDistance = 0.0F;
            le.hurtMarked = true;
        }
    }

    /** Bedrock "ag1:siren_sound": a sound projectile spawned 16 blocks above, flying in a random direction. */
    private void fireSoundProjectile() {
        SirenSoundEntity p = new SirenSoundEntity(ModEntities.SIREN_SOUND.get(), this.level());
        p.setOwner(this);
        p.setPos(getX(), getY() + 16.0D, getZ());
        double dx = this.random.nextDouble() * 2.0D - 1.0D, dz = this.random.nextDouble() * 2.0D - 1.0D;
        double len = Math.max(Math.sqrt(dx * dx + dz * dz), 0.001D);
        p.setDeltaMovement(dx / len * 0.9D * this.random.nextDouble(), 0.2D + this.random.nextDouble() * 0.4D, dz / len * 0.9D * this.random.nextDouble());
        this.level().addFreshEntity(p);
    }

    /** camera shake for nearby players, handled client-side through entity events 100-103 */
    private void shake(int id) {
        this.level().broadcastEntityEvent(this, (byte) id);
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id >= 100 && id <= 103) {
            if (this.level().isClientSide) ClientHooks.shakeCamera(this, id);
        } else {
            super.handleEntityEvent(id);
        }
    }

    // ---------------------------------------------------------------- damage / death
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (source.getEntity() instanceof Player && source.getDirectEntity() == source.getEntity()) amount += PLAYER_MELEE_BONUS;
        return super.hurt(source, amount * (float) hpScale);
    }

    @Override
    public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }

    @Override
    public void die(DamageSource source) {
        this.deathSource = source;
        super.die(source);
        if (!this.level().isClientSide) {
            this.setState(IDLE);
            this.grabbed.clear();
            this.bossEvent.setProgress(0.0F);
        }
    }

    /** loot is dropped at the END of the 7 s death animation (Bedrock: ag1:siren_gone) */
    @Override
    protected void dropAllDeathLoot(DamageSource source) { }

    @Override
    protected void tickDeath() {
        this.deathTime++;
        if (this.level().isClientSide) return;
        ServerLevel sl = (ServerLevel) this.level();
        int t = this.deathTime;
        if (t == 1) this.lunge(0, -1.5D);
        if (t == 2) shake(101);
        if (t == 4 || t == 6) {
            for (LivingEntity v : victims(position(), 20.0D)) {
                if (t == 4) v.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 2, false, true));
                else v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, true));
            }
        }
        if (t == 30) {
            SirenWeaponEntity w = ModEntities.SIREN_WEAPON.get().create(sl);
            if (w != null) {
                Vec3 f = Vec3.directionFromRotation(0.0F, this.yBodyRot);
                w.moveTo(getX() - f.x, getY() + 16.0D, getZ() - f.z, this.yBodyRot, 0.0F);
                sl.addFreshEntity(w);
            }
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 12.0D, getZ(), 1, 0, 0, 0, 0);
            sl.sendParticles(ParticleTypes.LAVA, getX(), getY() + 12.0D, getZ(), 40, 1.5D, 1.5D, 1.5D, 0.0D);
        }
        if (t == 31) shake(100);
        if (t == 83) {
            shake(102);
            slam(10.0D, false);
        }
        if (t >= DEATH_TICKS && !this.isRemoved()) {
            if ((this.isAlwaysExperienceDropper() || this.lastHurtByPlayerTime > 0) && this.shouldDropExperience()
                    && sl.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
                ExperienceOrb.award(sl, this.position(), this.getExperienceReward());
            }
            super.dropAllDeathLoot(this.deathSource != null ? this.deathSource : this.damageSources().generic());
            sl.broadcastEntityEvent(this, (byte) 60);
            this.remove(Entity.RemovalReason.KILLED);
        }
    }

    // ---------------------------------------------------------------- misc overrides
    @Override public boolean isPushable() { return false; }
    @Override public PushReaction getPistonPushReaction() { return PushReaction.IGNORE; }
    @Override public boolean shouldDespawnInPeaceful() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean canBeLeashed(Player p) { return false; }
    @Override protected float getStandingEyeHeight(Pose pose, EntityDimensions dim) { return 11.0F; }
    @Override public AABB getBoundingBoxForCulling() { return this.getBoundingBox().inflate(12.0D, 4.0D, 12.0D); }

    // sounds: footsteps come ONLY from the walk animation (see mov/run keyframes) so they never double up
    @Override protected void playStepSound(BlockPos pos, BlockState state) { }
    @Override protected SoundEvent getHurtSound(DamageSource src) { return null; }
    @Override protected SoundEvent getDeathSound() { return null; }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (isSummoned()) this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    // ---------------------------------------------------------------- GeckoLib
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<SirenHeadEntity>(this, "main", 4, this::mainPredicate)
                .setSoundKeyframeHandler(this::onSoundKeyframe)
                .setParticleKeyframeHandler(this::onParticleKeyframe));
        controllers.add(new AnimationController<SirenHeadEntity>(this, "overlay", 4, this::overlayPredicate));
    }

    private PlayState mainPredicate(AnimationState<SirenHeadEntity> state) {
        String name;
        if (this.isDeadOrDying()) {
            name = ANIM_DED;
        } else {
            int s = getState();
            if (s >= 1 && s <= 8) name = "animation.Sh_ag1.att" + (s == 1 ? "" : String.valueOf(s));
            else if (s == RUSH_READY) name = "animation.Sh_ag1.rusrea";
            else if (s == RUSH) name = "animation.Sh_ag1.rus";
            else if (s == JUMP) name = "animation.Sh_ag1.jum";
            else if (this.smoothSpeed > 0.2F) name = ANIM_RUN;
            else if (this.smoothSpeed > 0.02F) name = ANIM_WALK;
            else name = ANIM_IDLE;
        }
        state.getController().setAnimation(RawAnimation.begin().then(name, Animation.LoopType.DEFAULT));
        return PlayState.CONTINUE;
    }

    private PlayState overlayPredicate(AnimationState<SirenHeadEntity> state) {
        if (this.isDeadOrDying() || getState() == 8) {
            state.getController().setAnimation(RawAnimation.begin().then(ANIM_DED_SIREN, Animation.LoopType.DEFAULT));
            return PlayState.CONTINUE;
        }
        return PlayState.STOP;
    }

    private void onSoundKeyframe(SoundKeyframeEvent<SirenHeadEntity> event) {
        SoundEvent sound = ModSounds.byKeyframe(event.getKeyframeData().getSound());
        if (sound != null) {
            this.level().playLocalSound(getX(), getY(), getZ(), sound, SoundSource.HOSTILE, 1.0F, 1.0F, false);
        }
    }

    private void onParticleKeyframe(ParticleKeyframeEvent<SirenHeadEntity> event) {
        String effect = event.getKeyframeData().getEffect();
        String locator = event.getKeyframeData().getLocator();
        if ("footdust".equals(effect)) {
            // one footstep sound per foot plant, de-duplicated (never twice within 6 ticks)
            if (!this.onGround() || this.tickCount - lastStepTick < 6) return;
            lastStepTick = this.tickCount;
        }
        ClientHooks.onParticle(this, effect, locator);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.cache; }
}
