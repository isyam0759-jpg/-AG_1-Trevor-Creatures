package com.ag1.trevorcreature;

import com.ag1.trevorcreature.entity.SirenHeadEntity;
import com.ag1.trevorcreature.entity.SirenSignEntity;
import com.ag1.trevorcreature.entity.SirenWeaponEntity;
import com.ag1.trevorcreature.registry.ModCreativeTabs;
import com.ag1.trevorcreature.registry.ModEffects;
import com.ag1.trevorcreature.registry.ModEntities;
import com.ag1.trevorcreature.registry.ModItems;
import com.ag1.trevorcreature.registry.ModSounds;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Forge 1.20.1 + GeckoLib 4 port of the Bedrock "Trevor Creature Add-on" (AG_1) - Siren Head.
 */
@Mod(TrevorCreatureMod.MOD_ID)
public class TrevorCreatureMod {
    public static final String MOD_ID = "trevorcreature";

    public TrevorCreatureMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModEffects.EFFECTS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModCreativeTabs.TABS.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener(this::onBuildTabs);
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.SIREN_HEAD.get(), SirenHeadEntity.createAttributes().build());
        event.put(ModEntities.SIREN_SIGN.get(), SirenSignEntity.createAttributes().build());
        event.put(ModEntities.SIREN_WEAPON.get(), SirenWeaponEntity.createAttributes().build());
    }

    /** Make sure the egg is listed in the vanilla "Spawn Eggs" creative tab (no /give needed). */
    private void onBuildTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.SIREN_HEAD_SPAWN_EGG.get());
        }
    }
}
