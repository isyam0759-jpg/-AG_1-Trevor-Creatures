package com.ag1.trevorcreature.registry;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + MOD_ID))
            .icon(() -> new ItemStack(ModItems.SIREN_SIGN.get()))
            .displayItems((params, out) -> {
                out.accept(ModItems.SIREN_HEAD_SPAWN_EGG.get());
                out.accept(ModItems.SIREN_SIGN.get());
                out.accept(ModItems.SIREN_SIGN_STAFF.get());
            })
            .build());

    private ModCreativeTabs() {}
}
