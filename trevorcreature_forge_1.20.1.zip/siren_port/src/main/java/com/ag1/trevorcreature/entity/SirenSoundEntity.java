package com.ag1.trevorcreature.entity;

import com.ag1.trevorcreature.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.network.NetworkHooks;

/** Port of Bedrock "ag1:siren_sound": invisible projectile that detonates on landing (r = 5, 9 damage). */
public class SirenSoundEntity extends ThrowableProjectile {
    private int life;

    public SirenSoundEntity(EntityType<? extends SirenSoundEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() { }

    @Override
    protected float getGravity() { return 0.1F; }

    @Override
    public void tick() {
        super.tick();
        this.life++;
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.NOTE, getX(), getY(), getZ(), random.nextDouble(), 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.CLOUD, getX(), getY(), getZ(), 0.0D, 0.0D, 0.0D);
        } else if (this.life > 300 || this.onGround()) {
            explode();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) explode();
    }

    private void explode() {
        if (this.isRemoved() || !(this.level() instanceof ServerLevel sl)) return;
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 0.5D, getZ(), 1, 0, 0, 0, 0);
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.SIREN_IMPACT.get(), SoundSource.HOSTILE, 1.0F, 1.2F);
        Entity owner = getOwner();
        DamageSource src = owner instanceof LivingEntity le ? sl.damageSources().mobAttack(le) : sl.damageSources().generic();
        for (LivingEntity v : sl.getEntitiesOfClass(LivingEntity.class, new AABB(blockPosition()).inflate(5.0D),
                e -> e.isAlive() && !SirenHeadEntity.isSirenFamily(e) && e.distanceToSqr(this) <= 25.0D
                        && !(e instanceof Player p && (p.isCreative() || p.isSpectator())))) {
            v.hurt(src, 9.0F);
        }
        this.discard();
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
