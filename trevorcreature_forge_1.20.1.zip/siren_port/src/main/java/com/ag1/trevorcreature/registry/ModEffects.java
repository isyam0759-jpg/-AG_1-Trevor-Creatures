package com.ag1.trevorcreature.registry;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import com.ag1.trevorcreature.effect.SirenDashEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MOD_ID);
    public static final RegistryObject<MobEffect> SIREN_DASH = EFFECTS.register("siren_dash", SirenDashEffect::new);

    private ModEffects() {}
}
