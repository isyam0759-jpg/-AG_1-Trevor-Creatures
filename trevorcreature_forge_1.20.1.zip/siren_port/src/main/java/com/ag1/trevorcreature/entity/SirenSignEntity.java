package com.ag1.trevorcreature.entity;

import com.ag1.trevorcreature.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.PushReaction;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Port of Bedrock "ag1:siren_sign". Hit it to start the 11 second countdown, then it turns into a Siren Head
 * (700 HP "summoned" version with boss bar) - same as the animation.shsag_spawn timeline in the add-on.
 */
public class SirenSignEntity extends Mob implements GeoEntity {
    private static final EntityDataAccessor<Boolean> DATA_ACTIVE =
            SynchedEntityData.defineId(SirenSignEntity.class, EntityDataSerializers.BOOLEAN);
    private static final int TRANSFORM_TICKS = 220; // 11.0 s

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int countdown;

    public SirenSignEntity(EntityType<? extends SirenSignEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ACTIVE, false);
    }

    public boolean isActive() { return this.entityData.get(DATA_ACTIVE); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Active", isActive());
        tag.putInt("Countdown", countdown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_ACTIVE, tag.getBoolean("Active"));
        this.countdown = tag.getInt("Countdown");
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (!this.level().isClientSide && !isActive()) {
            this.entityData.set(DATA_ACTIVE, true);
            this.countdown = 0;
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !isActive()) return;
        ServerLevel sl = (ServerLevel) this.level();
        int t = this.countdown++;
        if (t == 0) announce(sl, Component.translatable("trevorcreature.message.prepare"));
        else if (t % 20 == 0 && t <= 200) announce(sl, Component.literal("\u00a7l\u00a7m\u00a7k1\u00a7r\u00a7l\u00a7e" + (11 - t / 20) + "\u00a7l\u00a7m\u00a7k1"));
        if (t == 218) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.0D, getZ(), 80, 2.0D, 1.5D, 2.0D, 0.05D);
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.0D, getZ(), 6, 2.0D, 1.0D, 2.0D, 0.0D);
        }
        if (t >= TRANSFORM_TICKS) {
            announce(sl, Component.translatable("trevorcreature.message.here"));
            SirenHeadEntity head = ModEntities.SIREN_HEAD.get().create(sl);
            if (head != null) {
                head.moveTo(getX(), getY(), getZ(), getYRot(), 0.0F);
                head.setSummoned(true);
                sl.addFreshEntity(head);
            }
            this.discard();
        }
    }

    private void announce(ServerLevel sl, Component msg) {
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) < 128.0D * 128.0D) p.displayClientMessage(msg, true);
        }
    }

    @Override public boolean isPushable() { return false; }
    @Override public PushReaction getPistonPushReaction() { return PushReaction.IGNORE; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean canBeLeashed(Player p) { return false; }
    @Override public void knockback(double a, double b, double c) { }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<SirenSignEntity>(this, "main", 0, state -> {
            state.getController().setAnimation(RawAnimation.begin()
                    .then(isActive() ? "animation.Shs_ag1.ded" : "animation.Shs_ag1.spa", Animation.LoopType.DEFAULT));
            return PlayState.CONTINUE;
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.cache; }
}
