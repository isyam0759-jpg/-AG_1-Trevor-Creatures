package com.ag1.trevorcreature.registry;

import static com.ag1.trevorcreature.TrevorCreatureMod.MOD_ID;

import com.ag1.trevorcreature.item.SirenSignItem;
import com.ag1.trevorcreature.item.SirenSignStaffItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<Item> SIREN_HEAD_SPAWN_EGG = ITEMS.register("siren_head_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SIREN_HEAD, 0x2B2B2B, 0xB89B2E, new Item.Properties()));

    /** Bedrock "ag1:item_shign" - placing it starts the summoning countdown. */
    public static final RegistryObject<Item> SIREN_SIGN = ITEMS.register("siren_sign",
            () -> new SirenSignItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    /** Bedrock "ag1:shign" - dash weapon dropped by Siren Head. */
    public static final RegistryObject<Item> SIREN_SIGN_STAFF = ITEMS.register("siren_sign_staff",
            () -> new SirenSignStaffItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    private ModItems() {}
}
